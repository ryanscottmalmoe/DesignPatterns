
public class BlueSpruce extends Tree{
	public BlueSpruce()
	{
		description = "Colorado Blue Spruce tree decorated with";
	}
	public int cost()
	{
		return 20;
	}
}
