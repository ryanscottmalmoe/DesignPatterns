
public abstract class TreeDecorations extends Tree {
	public abstract String getDescription();
}
