
public class FraserFir extends Tree{
	public FraserFir()
	{
		description = "Fraser Fir tree decorated with";
	}
	public int cost()
	{
		return 12;
	}
}
