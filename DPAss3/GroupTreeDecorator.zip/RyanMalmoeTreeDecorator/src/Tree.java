
public abstract class Tree {
	
	String description = "unknown tree";
	public String getDescription()
	{
		return description;
	}
	
	public abstract int cost();
}
