
public class BallsSilver extends TreeDecorations{
	Tree tree;
	public BallsSilver(Tree tree)
	{
		this.tree = tree;
	}
	public String getDescription()
	{
		return tree.getDescription() + ", Balls Red";
	}
	public int cost()
	{
		return 3 + tree.cost();
	}
}
