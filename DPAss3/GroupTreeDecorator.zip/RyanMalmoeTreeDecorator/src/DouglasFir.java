
public class DouglasFir extends Tree{
	public DouglasFir()
	{
		description = "Douglas Fir tree decorated with";
	}
	public int cost()
	{
		return 15;
	}
}
