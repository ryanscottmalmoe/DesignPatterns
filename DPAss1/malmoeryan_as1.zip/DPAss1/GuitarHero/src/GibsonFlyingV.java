public class GibsonFlyingV implements GuitarBehavior {
	public void Guitar() {
		System.out.println("I'm playing a Gibson Flying V.");
	}
}

