public interface GuitarBehavior {
	public void Guitar();
}