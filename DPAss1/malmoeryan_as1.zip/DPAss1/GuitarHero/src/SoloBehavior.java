
public interface SoloBehavior {
	public void Solo();
}
