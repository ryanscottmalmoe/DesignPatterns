public class GuitarOnFire implements SoloBehavior {
	public void Solo() {
		System.out.println("I'm lighting my guitar on fire.");
	}
}