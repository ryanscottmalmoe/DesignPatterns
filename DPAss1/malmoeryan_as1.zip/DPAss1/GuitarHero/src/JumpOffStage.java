public class JumpOffStage implements SoloBehavior {
	public void Solo() {
		System.out.println("I'm jumping off the stage.");
	}
}