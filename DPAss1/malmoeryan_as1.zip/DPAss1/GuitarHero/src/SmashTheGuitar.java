public class SmashTheGuitar implements SoloBehavior {
	public void Solo() {
		System.out.println("I'm smashing my guitar.");
	}
}