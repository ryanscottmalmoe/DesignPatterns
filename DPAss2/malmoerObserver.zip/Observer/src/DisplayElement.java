
public interface DisplayElement {
	public void display(GoodGuys guys);
}
